#include <iostream>
#include <ql/quantlib.hpp>

using namespace std;
using namespace QuantLib;

namespace QuantLib
{
	int value = 1;
	Time t = 1.01;
}

int main()
{
	QuantLib::Date mydate(12, Month::Jan, 2022);
	int yy = mydate.year();
	int mm = mydate.month();
	int dd = mydate.dayOfMonth();

	std::cout << "Year: " << yy << std::endl;
	std::cout << "Month: " << mm << std::endl;
	std::cout << "Days: " << dd << std::endl;
}